﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Car : Form
    {
        public Car()
        {
            InitializeComponent();
        }
        string id = string.Empty;

        int tr = 0;
        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Car_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carrentalDataSet4.Cartbl' table. You can move, or remove it, as needed.
            this.cartblTableAdapter2.Fill(this.carrentalDataSet4.Cartbl);

            getdata();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (rno.Text!="" && brand.Text != "" && model.Text != "" && price.Text != "" && available.Text != "")
            {
                string sql = "insert into Cartbl values('" + rno.Text + "','" + brand.Text + "','" + model.Text + "','" + price.Text + "','" + available.SelectedItem.ToString() + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Done");
                rno.Text = brand.Text = model.Text = price.Text = available.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Enter Value");
            }
        }
        private void getdata()
        {
            string sql = "select * from Cartbl";
            SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
           
        }
       
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rno.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            brand.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            model.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            price.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            available.SelectedItem = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
        }
      

        private void btnedit_Click(object sender, EventArgs e)
        {
            
                string value = dataGridView1.SelectedCells[0].Value.ToString();
                String sql = "update Cartbl set RegNum='" + rno.Text + "',Brand='" + brand.Text + "',Model='" + model.Text + "',Price='" + price.Text + "',Available='" + available.Text + "' where RegNum='" + value + "'  ";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Your data update");
                rno.Text = brand.Text = model.Text = price.Text = available.Text = string.Empty;
            
            
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
           
                string value = dataGridView1.SelectedCells[0].Value.ToString();
                string sql = "delete from Cartbl where RegNum='" + value + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Your data deleted");
                rno.Text = brand.Text = model.Text = price.Text = available.Text = string.Empty;
           
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Mainform m1 = new Mainform();
            m1.Show();
            this.Hide();
        }

        private void rno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void available_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void rno_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
////////////////////////////////