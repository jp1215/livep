﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (uid.Text != "" && uname.Text != "" && upass.Text != "")
            {
                string sql = "insert into Usertbl values('" + uid.Text + "','" + uname.Text + "','" + upass.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Done");
                uid.Text = uname.Text = upass.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Enter Value");
            }




        }
        private void getdata()
        {
            string sql = "select * from Usertbl";
            SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void User_Load(object sender, EventArgs e)
        {
            this.usertblTableAdapter.Fill(this.carrentalDataSet1.Usertbl);
            getdata();

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            
               
                string sql = "delete from Usertbl where id='" + uid + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Your data deleted");
                uid.Text = uname.Text = upass.Text = string.Empty;
                    

        }




        private void btnback_Click(object sender, EventArgs e)
        {
            Mainform m1=new Mainform();
            m1.Show();
            this.Hide();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
           
              
                String sql = "update Usertbl set Uname='" + uname.Text + "',Upass='" + upass.Text + "'where id='" + uid + "'  ";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Your data update");
          

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            uid.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            uname.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            upass.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void label4_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void uid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }
    }
}
