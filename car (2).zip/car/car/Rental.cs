﻿using Guna.UI2.Designer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Rental : Form
    {
        public Rental()
        {
            InitializeComponent();
        }

        private void Rental_Load(object sender, EventArgs e)
        {
              // TODO: This line of code loads data into the 'carrentalDataSet11.Rentaltbl' table. You can move, or remove it, as needed.
            this.rentaltblTableAdapter2.Fill(this.carrentalDataSet11.Rentaltbl);
            // TODO: This line of code loads data into the 'carrentalDataSet10.Rentaltbl' table. You can move, or remove it, as needed.
            this.rentaltblTableAdapter1.Fill(this.carrentalDataSet10.Rentaltbl);
            // TODO: This line of code loads data into the 'carrentalDataSet6.Rentaltbl' table. You can move, or remove it, as needed.
            this.rentaltblTableAdapter.Fill(this.carrentalDataSet6.Rentaltbl);
            fillcombo();
            fillCustomer();
            fetchCustName();
            getdata();

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (rentid.Text != "" && carreg.Text != "" && custid.Text != "" && custname.Text != "" && rentdate.Text != "" && returndate.Text != "" && rentfee.Text != "")
            {
                string sql = "insert into Rentaltbl values('" + rentid.Text + "','" + carreg.SelectedValue.ToString() + "','" + custid.Text + "','" + custname.Text + "','" + rentdate.Text + "','" + returndate.Text + "','" + rentfee.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Done");
                rentid.Text = carreg.Text = custid.Text = custname.Text = rentdate.Text = returndate.Text = rentfee.Text = string.Empty;
               updateonRent();
            }
            else
            {
                MessageBox.Show("Enter Value");
            }
        }
        private void getdata()
        {
            string sql = "select * from Rentaltbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void rentdate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            string value = dataGridView1.SelectedCells[0].Value.ToString();
            String sql = "update Rentaltbl set RentId='" + rentid.Text + "',carReg='" + carreg.Text + "',CustId='" + custid.Text + "',CustName='" + custname.Text + "',RentDate='" + rentdate.Text + "',ReturnDate='" + returndate.Text + "',RentFee='" + rentfee.Text + "' where RentId='" + value + "'  ";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            getdata();
            MessageBox.Show("Your data update");
            rentid.Text = carreg.Text = custid.Text = custname.Text = rentdate.Text = returndate.Text = rentfee.Text = string.Empty;
        }


        private void rentid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void custid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void rentfee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
           
            string sql = "delete from Rentaltbl where RentId='" + rentid + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            getdata();
            MessageBox.Show("Your data deleted");
            updateonRentDelete();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Mainform m1 = new Mainform();
            m1.Show();
            this.Hide();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
       
        }
        private void updateonRent()
        {
            Class1.cn.Open();
            String query = "update Cartbl set Available='" + "No" + "' where RegNum='" + carreg.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query,Class1.cn);
            cmd.ExecuteNonQuery();
            Class1.cn.Close();
        }
        private void updateonRentDelete()
        {
            Class1.cn.Open();
            String query = "update Cartbl set Available='" + "yes" + "' where RegNum='" + carreg.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query, Class1.cn);
            cmd.ExecuteNonQuery();
            Class1.cn.Close();
        }
        private void fillcombo()
        {
            Class1.cn.Open();
            
            String sql = "select  RegNum from Cartbl";
            SqlCommand cmd=new SqlCommand(sql,Class1.cn);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RegNum", typeof(string));
            dt.Load(rdr);
            carreg.ValueMember = "RegNum";
            carreg.DataSource = dt;
            Class1.cn.Close();

        }

        private void carreg_SelectionChangeCommitted(object sender, EventArgs e)
        {

        }
        private void fillCustomer()
        {
            Class1.cn.Open();

            String sql = "select  custid from Customertbl";
            SqlCommand cmd = new SqlCommand(sql, Class1.cn);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("custid", typeof(string));
            dt.Load(rdr);
            custid.ValueMember = "custid";
            custid.DataSource = dt;
            Class1.cn.Close();

        }

        private void fetchCustName()
        {
           

            String sql = "select * from Customertbl where custid="+custid.SelectedValue.ToString()+"";
            SqlCommand cmd = new SqlCommand(sql,Class1.cn);
           
            DataTable dt = new DataTable();
            SqlDataAdapter da= new SqlDataAdapter(cmd);
           da.Fill(dt);
            foreach (DataRow dr in dt.Rows) 
            {
                custname.Text = dr["custname"].ToString();
            }
          

        }

        private void custname_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchCustName();
        }
    }
}
