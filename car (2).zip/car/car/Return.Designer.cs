﻿namespace car
{
    partial class Return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Return));
            this.btnback = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.customertblTableAdapter = new car.carrentalDataSet5TableAdapters.CustomertblTableAdapter();
            this.carrentalDataSet5 = new car.carrentalDataSet5();
            this.customertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnedit = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.rid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.rdelay = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rfine = new System.Windows.Forms.TextBox();
            this.rdate = new System.Windows.Forms.DateTimePicker();
            this.returntblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carrentalDataSet12 = new car.carrentalDataSet12();
            this.returntblTableAdapter = new car.carrentalDataSet12TableAdapters.ReturntblTableAdapter();
            this.carid = new System.Windows.Forms.ComboBox();
            this.rname = new System.Windows.Forms.ComboBox();
            this.rentaltblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carrentalDataSet13 = new car.carrentalDataSet13();
            this.rentaltblTableAdapter = new car.carrentalDataSet13TableAdapters.RentaltblTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.RentDGV = new System.Windows.Forms.DataGridView();
            this.ReturnDGV = new System.Windows.Forms.DataGridView();
            this.carrentalDataSet14 = new car.carrentalDataSet14();
            this.rentaltblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.rentaltblTableAdapter1 = new car.carrentalDataSet14TableAdapters.RentaltblTableAdapter();
            this.rentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carRegDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returnDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentFeeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carrentalDataSet15 = new car.carrentalDataSet15();
            this.returntblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.returntblTableAdapter1 = new car.carrentalDataSet15TableAdapters.ReturntblTableAdapter();
            this.returnIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carRegDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returnDateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customertblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RentDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnback
            // 
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(121, 365);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(91, 35);
            this.btnback.TabIndex = 71;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.Location = new System.Drawing.Point(243, 320);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(94, 35);
            this.btndelete.TabIndex = 70;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(11, 320);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(89, 35);
            this.btnadd.TabIndex = 68;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // customertblTableAdapter
            // 
            this.customertblTableAdapter.ClearBeforeFill = true;
            // 
            // carrentalDataSet5
            // 
            this.carrentalDataSet5.DataSetName = "carrentalDataSet5";
            this.carrentalDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customertblBindingSource
            // 
            this.customertblBindingSource.DataMember = "Customertbl";
            this.customertblBindingSource.DataSource = this.carrentalDataSet5;
            // 
            // btnedit
            // 
            this.btnedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnedit.Location = new System.Drawing.Point(121, 320);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(91, 35);
            this.btnedit.TabIndex = 69;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = true;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(10, 171);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 24);
            this.label4.TabIndex = 63;
            this.label4.Text = "Name";
            // 
            // rid
            // 
            this.rid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rid.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rid.Location = new System.Drawing.Point(132, 94);
            this.rid.Margin = new System.Windows.Forms.Padding(4);
            this.rid.Name = "rid";
            this.rid.Size = new System.Drawing.Size(207, 29);
            this.rid.TabIndex = 61;
            this.rid.TextChanged += new System.EventHandler(this.rid_TextChanged);
            this.rid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rid_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(8, 134);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 24);
            this.label1.TabIndex = 60;
            this.label1.Text = "Carid";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(13, 97);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 24);
            this.label3.TabIndex = 59;
            this.label3.Text = "Id";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(-4, 423);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(783, 22);
            this.panel2.TabIndex = 58;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 85);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(300, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(205, 54);
            this.label2.TabIndex = 37;
            this.label2.Text = "Return";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(10, 206);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 24);
            this.label5.TabIndex = 64;
            this.label5.Text = "ReturnDate";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(-4, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 71);
            this.panel1.TabIndex = 57;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(13, 242);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 24);
            this.label6.TabIndex = 72;
            this.label6.Text = "Delay";
            // 
            // rdelay
            // 
            this.rdelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdelay.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rdelay.Location = new System.Drawing.Point(132, 237);
            this.rdelay.Margin = new System.Windows.Forms.Padding(4);
            this.rdelay.Name = "rdelay";
            this.rdelay.Size = new System.Drawing.Size(207, 29);
            this.rdelay.TabIndex = 73;
            this.rdelay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rdelay_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(13, 279);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 24);
            this.label7.TabIndex = 74;
            this.label7.Text = "Fine";
            // 
            // rfine
            // 
            this.rfine.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rfine.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rfine.Location = new System.Drawing.Point(131, 274);
            this.rfine.Margin = new System.Windows.Forms.Padding(4);
            this.rfine.Name = "rfine";
            this.rfine.Size = new System.Drawing.Size(207, 29);
            this.rfine.TabIndex = 75;
            this.rfine.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rfine_KeyPress);
            // 
            // rdate
            // 
            this.rdate.Location = new System.Drawing.Point(131, 204);
            this.rdate.Name = "rdate";
            this.rdate.Size = new System.Drawing.Size(208, 26);
            this.rdate.TabIndex = 76;
            // 
            // returntblBindingSource
            // 
            this.returntblBindingSource.DataMember = "Returntbl";
            this.returntblBindingSource.DataSource = this.carrentalDataSet12;
            // 
            // carrentalDataSet12
            // 
            this.carrentalDataSet12.DataSetName = "carrentalDataSet12";
            this.carrentalDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // returntblTableAdapter
            // 
            this.returntblTableAdapter.ClearBeforeFill = true;
            // 
            // carid
            // 
            this.carid.FormattingEnabled = true;
            this.carid.Location = new System.Drawing.Point(131, 133);
            this.carid.Name = "carid";
            this.carid.Size = new System.Drawing.Size(208, 28);
            this.carid.TabIndex = 78;
//            this.carid.SelectedIndexChanged += new System.EventHandler(this.carregcb_SelectedIndexChanged);
            // 
            // rname
            // 
            this.rname.FormattingEnabled = true;
            this.rname.Location = new System.Drawing.Point(132, 171);
            this.rname.Name = "rname";
            this.rname.Size = new System.Drawing.Size(207, 28);
            this.rname.TabIndex = 79;
            // 
            // rentaltblBindingSource
            // 
            this.rentaltblBindingSource.DataMember = "Rentaltbl";
            this.rentaltblBindingSource.DataSource = this.carrentalDataSet13;
            // 
            // carrentalDataSet13
            // 
            this.carrentalDataSet13.DataSetName = "carrentalDataSet13";
            this.carrentalDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rentaltblTableAdapter
            // 
            this.rentaltblTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Turquoise;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(485, 237);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 24);
            this.label8.TabIndex = 81;
            this.label8.Text = "Cars Returned";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Turquoise;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(485, 73);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 24);
            this.label9.TabIndex = 82;
            this.label9.Text = "Cars on Rent";
            // 
            // RentDGV
            // 
            this.RentDGV.AutoGenerateColumns = false;
            this.RentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RentDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rentIdDataGridViewTextBoxColumn,
            this.carRegDataGridViewTextBoxColumn,
            this.custIdDataGridViewTextBoxColumn,
            this.custNameDataGridViewTextBoxColumn,
            this.rentDateDataGridViewTextBoxColumn,
            this.returnDateDataGridViewTextBoxColumn,
            this.rentFeeDataGridViewTextBoxColumn});
            this.RentDGV.DataSource = this.rentaltblBindingSource1;
            this.RentDGV.Location = new System.Drawing.Point(363, 94);
            this.RentDGV.Name = "RentDGV";
            this.RentDGV.Size = new System.Drawing.Size(400, 140);
            this.RentDGV.TabIndex = 83;
            this.RentDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.RentDGV_CellContentClick);
            // 
            // ReturnDGV
            // 
            this.ReturnDGV.AutoGenerateColumns = false;
            this.ReturnDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ReturnDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.returnIdDataGridViewTextBoxColumn,
            this.carRegDataGridViewTextBoxColumn1,
            this.custNameDataGridViewTextBoxColumn1,
            this.returnDateDataGridViewTextBoxColumn1,
            this.delayDataGridViewTextBoxColumn,
            this.fineDataGridViewTextBoxColumn});
            this.ReturnDGV.DataSource = this.returntblBindingSource1;
            this.ReturnDGV.Location = new System.Drawing.Point(363, 264);
            this.ReturnDGV.Name = "ReturnDGV";
            this.ReturnDGV.Size = new System.Drawing.Size(400, 140);
            this.ReturnDGV.TabIndex = 84;
            // 
            // carrentalDataSet14
            // 
            this.carrentalDataSet14.DataSetName = "carrentalDataSet14";
            this.carrentalDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rentaltblBindingSource1
            // 
            this.rentaltblBindingSource1.DataMember = "Rentaltbl";
            this.rentaltblBindingSource1.DataSource = this.carrentalDataSet14;
            // 
            // rentaltblTableAdapter1
            // 
            this.rentaltblTableAdapter1.ClearBeforeFill = true;
            // 
            // rentIdDataGridViewTextBoxColumn
            // 
            this.rentIdDataGridViewTextBoxColumn.DataPropertyName = "RentId";
            this.rentIdDataGridViewTextBoxColumn.HeaderText = "RentId";
            this.rentIdDataGridViewTextBoxColumn.Name = "rentIdDataGridViewTextBoxColumn";
            // 
            // carRegDataGridViewTextBoxColumn
            // 
            this.carRegDataGridViewTextBoxColumn.DataPropertyName = "carReg";
            this.carRegDataGridViewTextBoxColumn.HeaderText = "carReg";
            this.carRegDataGridViewTextBoxColumn.Name = "carRegDataGridViewTextBoxColumn";
            // 
            // custIdDataGridViewTextBoxColumn
            // 
            this.custIdDataGridViewTextBoxColumn.DataPropertyName = "CustId";
            this.custIdDataGridViewTextBoxColumn.HeaderText = "CustId";
            this.custIdDataGridViewTextBoxColumn.Name = "custIdDataGridViewTextBoxColumn";
            // 
            // custNameDataGridViewTextBoxColumn
            // 
            this.custNameDataGridViewTextBoxColumn.DataPropertyName = "CustName";
            this.custNameDataGridViewTextBoxColumn.HeaderText = "CustName";
            this.custNameDataGridViewTextBoxColumn.Name = "custNameDataGridViewTextBoxColumn";
            // 
            // rentDateDataGridViewTextBoxColumn
            // 
            this.rentDateDataGridViewTextBoxColumn.DataPropertyName = "RentDate";
            this.rentDateDataGridViewTextBoxColumn.HeaderText = "RentDate";
            this.rentDateDataGridViewTextBoxColumn.Name = "rentDateDataGridViewTextBoxColumn";
            // 
            // returnDateDataGridViewTextBoxColumn
            // 
            this.returnDateDataGridViewTextBoxColumn.DataPropertyName = "ReturnDate";
            this.returnDateDataGridViewTextBoxColumn.HeaderText = "ReturnDate";
            this.returnDateDataGridViewTextBoxColumn.Name = "returnDateDataGridViewTextBoxColumn";
            // 
            // rentFeeDataGridViewTextBoxColumn
            // 
            this.rentFeeDataGridViewTextBoxColumn.DataPropertyName = "RentFee";
            this.rentFeeDataGridViewTextBoxColumn.HeaderText = "RentFee";
            this.rentFeeDataGridViewTextBoxColumn.Name = "rentFeeDataGridViewTextBoxColumn";
            // 
            // carrentalDataSet15
            // 
            this.carrentalDataSet15.DataSetName = "carrentalDataSet15";
            this.carrentalDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // returntblBindingSource1
            // 
            this.returntblBindingSource1.DataMember = "Returntbl";
            this.returntblBindingSource1.DataSource = this.carrentalDataSet15;
            // 
            // returntblTableAdapter1
            // 
            this.returntblTableAdapter1.ClearBeforeFill = true;
            // 
            // returnIdDataGridViewTextBoxColumn
            // 
            this.returnIdDataGridViewTextBoxColumn.DataPropertyName = "ReturnId";
            this.returnIdDataGridViewTextBoxColumn.HeaderText = "ReturnId";
            this.returnIdDataGridViewTextBoxColumn.Name = "returnIdDataGridViewTextBoxColumn";
            // 
            // carRegDataGridViewTextBoxColumn1
            // 
            this.carRegDataGridViewTextBoxColumn1.DataPropertyName = "CarReg";
            this.carRegDataGridViewTextBoxColumn1.HeaderText = "CarReg";
            this.carRegDataGridViewTextBoxColumn1.Name = "carRegDataGridViewTextBoxColumn1";
            // 
            // custNameDataGridViewTextBoxColumn1
            // 
            this.custNameDataGridViewTextBoxColumn1.DataPropertyName = "CustName";
            this.custNameDataGridViewTextBoxColumn1.HeaderText = "CustName";
            this.custNameDataGridViewTextBoxColumn1.Name = "custNameDataGridViewTextBoxColumn1";
            // 
            // returnDateDataGridViewTextBoxColumn1
            // 
            this.returnDateDataGridViewTextBoxColumn1.DataPropertyName = "ReturnDate";
            this.returnDateDataGridViewTextBoxColumn1.HeaderText = "ReturnDate";
            this.returnDateDataGridViewTextBoxColumn1.Name = "returnDateDataGridViewTextBoxColumn1";
            // 
            // delayDataGridViewTextBoxColumn
            // 
            this.delayDataGridViewTextBoxColumn.DataPropertyName = "Delay";
            this.delayDataGridViewTextBoxColumn.HeaderText = "Delay";
            this.delayDataGridViewTextBoxColumn.Name = "delayDataGridViewTextBoxColumn";
            // 
            // fineDataGridViewTextBoxColumn
            // 
            this.fineDataGridViewTextBoxColumn.DataPropertyName = "Fine";
            this.fineDataGridViewTextBoxColumn.HeaderText = "Fine";
            this.fineDataGridViewTextBoxColumn.Name = "fineDataGridViewTextBoxColumn";
            // 
            // Return
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Turquoise;
            this.ClientSize = new System.Drawing.Size(775, 444);
            this.Controls.Add(this.ReturnDGV);
            this.Controls.Add(this.RentDGV);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.rname);
            this.Controls.Add(this.carid);
            this.Controls.Add(this.rdate);
            this.Controls.Add(this.rfine);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.rdelay);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnedit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Return";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Return";
            this.Load += new System.EventHandler(this.Return_Load);
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customertblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RentDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReturnDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnadd;
        private carrentalDataSet5TableAdapters.CustomertblTableAdapter customertblTableAdapter;
        private carrentalDataSet5 carrentalDataSet5;
        private System.Windows.Forms.BindingSource customertblBindingSource;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox rid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox rdelay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox rfine;
        private System.Windows.Forms.DateTimePicker rdate;
        private carrentalDataSet12 carrentalDataSet12;
        private System.Windows.Forms.BindingSource returntblBindingSource;
        private carrentalDataSet12TableAdapters.ReturntblTableAdapter returntblTableAdapter;
        private System.Windows.Forms.ComboBox carid;
        private System.Windows.Forms.ComboBox rname;
        private carrentalDataSet13 carrentalDataSet13;
        private System.Windows.Forms.BindingSource rentaltblBindingSource;
        private carrentalDataSet13TableAdapters.RentaltblTableAdapter rentaltblTableAdapter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView RentDGV;
        private System.Windows.Forms.DataGridView ReturnDGV;
        private carrentalDataSet14 carrentalDataSet14;
        private System.Windows.Forms.BindingSource rentaltblBindingSource1;
        private carrentalDataSet14TableAdapters.RentaltblTableAdapter rentaltblTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carRegDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentFeeDataGridViewTextBoxColumn;
        private carrentalDataSet15 carrentalDataSet15;
        private System.Windows.Forms.BindingSource returntblBindingSource1;
        private carrentalDataSet15TableAdapters.ReturntblTableAdapter returntblTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carRegDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn custNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnDateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn delayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fineDataGridViewTextBoxColumn;
    }
}