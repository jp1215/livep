﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Return : Form
    {
        public Return()
        {
            InitializeComponent();
        }
        private void populate()
        {
            Class1.cn.Open();
            string sql = "select * from Rentaltbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ReturnDGV.DataSource = ds.Tables[0];
            Class1.cn.Close();

        }
        private void Return_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carrentalDataSet14.Rentaltbl' table. You can move, or remove it, as needed.
            this.rentaltblTableAdapter1.Fill(this.carrentalDataSet14.Rentaltbl);

            populate();
            populateRet();

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (rid.Text != "" && carid.Text != "" && rname.Text != "" && rdate.Text != "" && rdelay.Text != "" && rfine.Text != "")
            {
                string sql = "insert into Returntbl values('" + rid.Text + "','" + carid.Text + "','" + rname.Text + "','" + rdate.Text + "','" + rdelay.Text + "','" + rfine.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                populate();
                MessageBox.Show("Done");
                rid.Text = carid.Text = rname.Text = rdate.Text = rdelay.Text = rfine.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Enter Value");
            }
        }
        

        private void btnedit_Click(object sender, EventArgs e)
        {

            string value = RentDGV.SelectedCells[0].Value.ToString();
            String sql = "update Returntbl set ReturnId='" + rid.Text + "',Carreg='" + carid.Text + "',CustName='" + rname.Text + "',ReturnDate='" + rdate.Text + "',Delay='" + rdelay.Text + "',Fine='" + rfine.Text + "' where ReturnId='" + value + "'  ";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            populate();
            MessageBox.Show("Your data update");
            rid.Text = carid.Text = rname.Text = rdate.Text = rdelay.Text = rfine.Text = string.Empty;

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Mainform m1 = new Mainform();
            m1.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            
            string sql = "delete from Returntbl where ReturnId='" + rid + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            populate();
            MessageBox.Show("Your data deleted");
            rid.Text = carid.Text = rname.Text = rdate.Text = rdelay.Text = rfine.Text = string.Empty;

        }

        

        private void rid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void rdelay_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void rfine_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        
        private void populateRet()
        {
            string sql = "select * from Returntbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ReturnDGV.DataSource = ds.Tables[0];


        }
        
        private void Deleteonreturn()
        {
            int rentid;
            rentid = Convert.ToInt32(RentDGV.SelectedRows[0].Cells[0].Value.ToString());
            Class1.cn.Open();
            string query = "delete from Rentaltbl Where Rentid=" + rentid + ";";
            SqlCommand cmd= new SqlCommand(query, Class1.cn);
            cmd.ExecuteNonQuery();
            Class1.cn.Close();
            populate();
        }
        

    

        private void rid_TextChanged(object sender, EventArgs e)
        {

        }

        private void RentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            carid.Text = RentDGV.SelectedRows[0].Cells[1].Value.ToString();
            rname.Text = RentDGV.SelectedRows[0].Cells[2].Value.ToString();
            rdate.Text = RentDGV.SelectedRows[0].Cells[3].Value.ToString();
            DateTime d1 = rdate.Value.Date;
            DateTime d2 = DateTime.Now;
            TimeSpan t = d2 - d1;
            int NrofDays = Convert.ToInt32(t.TotalDays);
            if (NrofDays <= 0)
            {
                rdelay.Text = "No Delay";
                rfine.Text = "0";

            }
            else
            {
                rdelay.Text = "" + NrofDays;
                rfine.Text = "" + (NrofDays * 250);

            }
        }
    }
}
