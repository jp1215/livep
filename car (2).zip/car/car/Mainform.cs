﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Mainform : Form
    {
        public Mainform()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User u1 = new User();
            u1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Car car = new Car();
            car.Show();
            this.Hide();
        }

        private void Mainform_Load(object sender, EventArgs e)
        {
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Login l1=new Login();
            l1.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Customer c1=new Customer(); 
            c1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Rental r1= new Rental();
            r1.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Return r2 = new Return();
            r2.Show();
            this.Hide();
        }
    }
}