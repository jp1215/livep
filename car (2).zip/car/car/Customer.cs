﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carrentalDataSet5.Customertbl' table. You can move, or remove it, as needed.
            this.customertblTableAdapter.Fill(this.carrentalDataSet5.Customertbl);
            getdata();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (custid.Text != "" && custnm.Text != "" && custadd.Text != "" && custphone.Text != "" )
            {
                string sql = "insert into Customertbl values('" + custid.Text + "','" + custnm.Text + "','" + custadd.Text + "','" + custphone.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getdata();
                MessageBox.Show("Done");
                custid.Text = custnm.Text = custadd.Text = custphone.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Enter Value");
            }
        }
        private void getdata()
        {
            string sql = "select * from Customertbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            string value = dataGridView1.SelectedCells[0].Value.ToString();
            String sql = "update Customertbl set CustId='" + custid.Text + "',CustName='" + custnm.Text + "',CustAdd='" + custadd.Text + "',Phone='" + custphone.Text + "' where CustId='" + value + "'  ";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            getdata();
            MessageBox.Show("Your data update");
            custid.Text = custnm.Text = custadd.Text = custphone.Text = string.Empty;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string value = dataGridView1.SelectedCells[0].Value.ToString();
            string sql = "delete from Customertbl where CustId='" + value + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            getdata();
            MessageBox.Show("Your data deleted");
           
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Mainform m1 = new Mainform();
            m1.Show();
            this.Hide();
        }

        private void custid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void custphone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }
    }
}
